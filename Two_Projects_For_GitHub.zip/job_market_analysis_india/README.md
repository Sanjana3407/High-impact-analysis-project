# Job Market Analysis – Data Analyst Roles (India)

Sample to demonstrate: skills parsing, salary by city, and work-mode distribution.

## Files
- `data_analyst_jobs_india.csv`
- `top_skills.png`
- `avg_salary_by_city.png`
- `work_mode_distribution.png`
- `Job_Market_Analysis.ipynb`