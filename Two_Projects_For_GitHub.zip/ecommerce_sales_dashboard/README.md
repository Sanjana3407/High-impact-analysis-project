# E-commerce Sales Dashboard & Insights

Dataset: compact Superstore-style sample (~200 orders).  
KPIs, category/region performance, and monthly trend visualized.

## Files
- `ecommerce_sales.csv`
- `sales_by_category.png`
- `monthly_sales_trend.png`
- `sales_by_region.png`
- `Ecommerce_Sales_Analysis.ipynb`